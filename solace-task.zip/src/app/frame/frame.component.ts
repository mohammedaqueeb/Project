import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-frame',
  templateUrl: './frame.component.html',
  styleUrls: ['./frame.component.css']
})
export class FrameComponent implements OnInit {

  width : string = '500';
  height : string = '500';
  

  public imagePath : any;
  imgURL: any = 'assets/images/custom_photo_frame.png';
  public message: any;

  constructor() { }


  ngOnInit(): void {
      this.changeColor('aqua');
      this.changeImage('1');
  }

  
 
  preview(files :any) {

    if (files.length === 0)
      return;
 
    var mimeType = files[0].type;
    if (mimeType.match(/image\/*/) == null) {
      this.message = "Only images are supported.";
      alert(this.message);
      return;
    }
 
    var reader = new FileReader();
    this.imagePath = files;
    reader.readAsDataURL(files[0]); 
    reader.onload = (_event) => { 
      this.imgURL = reader.result; 
    }
  }

  changeColor(color : string){

    let doc = document.getElementById("frameBackground")!;    
    doc.style.backgroundColor = color;

  }

  changeImage(image : string){

      this.imgURL = 'assets/images/'+image+'.jpg'; 
  }



}

